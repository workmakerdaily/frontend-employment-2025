"use client";

import Link from 'next/link';

const SideBar = () => {
    return (
        <aside className="w-60 bg-blue-300 h-screen p-4 text-white">
            <nav>
                <ul className="space-y-4">
                    <li>
                        <Link href="/" className="block p-2 hover:bg-blue-400 rounded">
                            Main
                        </Link>
                    </li>
                    <li>
                        <Link href="/pokemons" className="block p-2 hover:bg-blue-400 rounded">
                            Pokemon
                        </Link>
                    </li>
                    <li>
                        <Link href="/sign-in" className="block p-2 hover:bg-blue-400 rounded">
                            Sign-In
                        </Link>
                    </li>
                    <li>
                        <Link href="/sign-up" className="block p-2 hover:bg-blue-400 rounded">
                            Sign-Up
                        </Link>
                    </li>
                    <li>
                        <Link href="/admin" className="block p-2 hover:bg-blue-400 rounded">
                            Admin
                        </Link>
                        <Link href="/admin/users" className="block p-2 hover:bg-blue-400 rounded">
                            User
                        </Link>
                    </li>
                </ul>
            </nav>
        </aside>
    );
};

export default SideBar;