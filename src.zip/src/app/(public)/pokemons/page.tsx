import PokemonList from "@/components/PokemonList";

// component: 포켓몬 페이지 //
export default function PokemonPage() {
    
    // render: 포켓몬 페이지 렌더링 //
    return (
        <div>
            <PokemonList />
        </div>
    );
}