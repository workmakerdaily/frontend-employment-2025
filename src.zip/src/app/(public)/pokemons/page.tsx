import PokemonList from "@/components/PokemonList";

export default function PokemonPage() {
    return (
        <div>
            <PokemonList />
        </div>
    );
}