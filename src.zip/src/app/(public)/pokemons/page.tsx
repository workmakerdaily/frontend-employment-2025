import PokemonList from "@/components/PokemonList";

export default function PokemonPage() {
    return (
        <div className="p-4">
            <PokemonList />
        </div>
    );
}