import Banner from "@/components/Banner";

// component: 메인 페이지 //
export default function Main() {

  // render: 메인 페이지 렌더링 //
  return <div className="px-4">
    <Banner />
  </div>;
}
