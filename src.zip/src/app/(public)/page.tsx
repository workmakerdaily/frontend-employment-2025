export default function Home() {
  return <section></section>;
}
