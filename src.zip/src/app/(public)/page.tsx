import Banner from "@/components/Banner";

export default function Main() {
  return <div className="px-4">
    <Banner />
  </div>;
}
