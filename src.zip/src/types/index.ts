import GetPokemon from "./get-pokemon.interface";

export type {
    GetPokemon,
}