import GetPokemon from "./get-pokemon.interface";
import User from "./User.interface";

export type {
    GetPokemon,
    User,
}