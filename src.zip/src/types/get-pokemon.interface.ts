export default interface GetPokemon {
    name: string;
    image: string;
}