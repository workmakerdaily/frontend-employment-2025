export default interface User {
    name: string;
    email: string;
    age: number;
    region: string;
}
